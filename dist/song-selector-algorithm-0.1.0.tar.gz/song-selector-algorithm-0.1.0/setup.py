# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['song_selector_algorithm',
 'song_selector_algorithm.common',
 'song_selector_algorithm.core']

package_data = \
{'': ['*'], 'song_selector_algorithm': ['data/*']}

setup_kwargs = {
    'name': 'song-selector-algorithm',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Glenn Viroux',
    'author_email': 'glenn.viroux@ehealtho.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
